local Hole = Class(function(self, inst)
    
    self.inst = inst
    self.canbury = false
    
end)

return Hole