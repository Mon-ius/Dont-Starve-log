local EventHandler = GLOBAL.EventHandler
local State = GLOBAL.State
local ACTIONS = GLOBAL.ACTIONS
local TheInput = GLOBAL.TheInput
local TimeEvent = GLOBAL.TimeEvent
local STRINGS = GLOBAL.STRINGS
local SpawnPrefab = GLOBAL.SpawnPrefab
local FRAMES = GLOBAL.FRAMES


